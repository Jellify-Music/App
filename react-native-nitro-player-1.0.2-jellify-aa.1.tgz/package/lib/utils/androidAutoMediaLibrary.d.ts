import type { MediaLibrary } from '../types/AndroidAutoMediaLibrary';
/**
 * Helper utilities for Android Auto Media Library
 * Android-only functionality
 */
export declare const AndroidAutoMediaLibraryHelper: {
    /**
     * Set the Android Auto media library structure
     * This defines what folders and playlists appear in Android Auto
     *
     * @param library - The media library structure
     *
     * @example
     * ```ts
     * AndroidAutoMediaLibraryHelper.set({
     *   layoutType: 'grid',
     *   rootItems: [
     *     {
     *       id: 'my_music',
     *       title: 'My Music',
     *       mediaType: 'folder',
     *       isPlayable: false,
     *       children: [
     *         {
     *           id: 'favorites',
     *           title: 'Favorites',
     *           mediaType: 'playlist',
     *           playlistId: 'favorites-playlist-id', // References a playlist created with PlayerQueue
     *           isPlayable: false,
     *         },
     *       ],
     *     },
     *   ],
     * })
     * ```
     */
    set: (library: MediaLibrary) => void;
    /**
     * Clear the Android Auto media library
     * Falls back to showing all playlists
     */
    clear: () => void;
    /**
     * Check if Android Auto Media Library is available (Android only)
     */
    isAvailable: () => boolean;
};
