import type { EqualizerBand } from '../types/EqualizerTypes';
export interface UseEqualizerResult {
    /** Whether the equalizer is enabled */
    isEnabled: boolean;
    /** Current band settings */
    bands: EqualizerBand[];
    /** Currently applied preset name */
    currentPreset: string | null;
    /** Toggle equalizer on/off */
    setEnabled: (enabled: boolean) => Promise<boolean>;
    /** Set gain for a specific band */
    setBandGain: (bandIndex: number, gainDb: number) => Promise<boolean>;
    /** Set all band gains at once */
    setAllBandGains: (gains: number[]) => Promise<boolean>;
    /** Reset to flat response */
    reset: () => Promise<void>;
    /** Whether equalizer is loading */
    isLoading: boolean;
    /** Gain range (min/max in dB) */
    gainRange: {
        min: number;
        max: number;
    };
}
export declare function useEqualizer(): UseEqualizerResult;
