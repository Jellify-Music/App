import type { DownloadConfig, PlaybackSource } from '../types/DownloadTypes';
import type { TrackItem } from '../types/PlayerQueue';
export interface UseDownloadActionsResult {
    downloadTrack: (track: TrackItem, playlistId?: string) => Promise<string>;
    downloadPlaylist: (playlistId: string, tracks: TrackItem[]) => Promise<string[]>;
    pauseDownload: (downloadId: string) => Promise<void>;
    resumeDownload: (downloadId: string) => Promise<void>;
    cancelDownload: (downloadId: string) => Promise<void>;
    retryDownload: (downloadId: string) => Promise<void>;
    pauseAll: () => Promise<void>;
    resumeAll: () => Promise<void>;
    cancelAll: () => Promise<void>;
    deleteTrack: (trackId: string) => Promise<void>;
    deletePlaylist: (playlistId: string) => Promise<void>;
    deleteAll: () => Promise<void>;
    configure: (config: DownloadConfig) => void;
    setPlaybackSourcePreference: (preference: PlaybackSource) => void;
    getPlaybackSourcePreference: () => PlaybackSource;
    isDownloading: boolean;
    isDeleting: boolean;
    error: Error | null;
}
/**
 * Hook for download actions (download, pause, resume, cancel, delete)
 */
export declare function useDownloadActions(): UseDownloadActionsResult;
