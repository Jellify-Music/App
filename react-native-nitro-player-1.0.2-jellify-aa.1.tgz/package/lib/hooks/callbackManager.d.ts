import type { TrackItem, TrackPlayerState, Reason } from '../types/PlayerQueue';
type PlaybackStateCallback = (state: TrackPlayerState, reason?: Reason) => void;
type TrackChangeCallback = (track: TrackItem, reason?: Reason) => void;
type PlaybackProgressCallback = (position: number, totalDuration: number, isManuallySeeked?: boolean) => void;
type SeekCallback = (position: number, totalDuration: number) => void;
/**
 * Internal subscription manager that allows multiple hooks to subscribe
 * to a single native callback. This solves the problem where registering
 * a new callback overwrites the previous one.
 */
declare class CallbackSubscriptionManager {
    private playbackStateSubscribers;
    private trackChangeSubscribers;
    private playbackProgressSubscribers;
    private seekSubscribers;
    private isPlaybackStateRegistered;
    private isTrackChangeRegistered;
    private isPlaybackProgressRegistered;
    private isSeekRegistered;
    /**
     * Subscribe to playback state changes
     * @returns Unsubscribe function
     */
    subscribeToPlaybackState(callback: PlaybackStateCallback): () => void;
    /**
     * Subscribe to track changes
     * @returns Unsubscribe function
     */
    subscribeToTrackChange(callback: TrackChangeCallback): () => void;
    private ensurePlaybackStateRegistered;
    private ensureTrackChangeRegistered;
    /**
     * Subscribe to playback progress changes
     * @returns Unsubscribe function
     */
    subscribeToPlaybackProgressChange(callback: PlaybackProgressCallback): () => void;
    /**
     * Subscribe to seek events
     * @returns Unsubscribe function
     */
    subscribeToSeek(callback: SeekCallback): () => void;
    private ensurePlaybackProgressRegistered;
    private ensureSeekRegistered;
}
export declare const callbackManager: CallbackSubscriptionManager;
export {};
