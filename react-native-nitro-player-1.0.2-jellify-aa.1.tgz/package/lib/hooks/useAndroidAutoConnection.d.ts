/**
 * Hook to detect Android Auto connection status using the official Android for Cars API
 * Based on: https://developer.android.com/training/cars/apps#car-connection
 *
 * @returns Object with isConnected boolean
 *
 * @example
 * const { isConnected } = useAndroidAutoConnection();
 * console.log('Android Auto connected:', isConnected);
 */
export declare function useAndroidAutoConnection(): {
    isConnected: boolean;
};
