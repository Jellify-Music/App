import type { TrackPlayerState, Reason } from '../types/PlayerQueue';
export interface PlaybackStateResult {
    state: TrackPlayerState;
    reason: Reason | undefined;
    isReady: boolean;
}
/**
 * Hook to subscribe to playback state changes.
 *
 * This hook provides real-time playback state updates using native callbacks.
 * Multiple components can use this hook simultaneously without interfering
 * with each other.
 *
 * @returns Object with:
 *   - state: Current playback state ('playing' | 'paused' | 'stopped')
 *   - reason: Reason for the last state change
 *   - isReady: Whether the initial state has been loaded
 *
 * @example
 * ```tsx
 * function PlaybackIndicator() {
 *   const { state, reason, isReady } = useOnPlaybackStateChange()
 *
 *   if (!isReady) return <Text>Loading...</Text>
 *
 *   return (
 *     <View>
 *       <Text>State: {state}</Text>
 *       {reason && <Text>Reason: {reason}</Text>}
 *     </View>
 *   )
 * }
 * ```
 */
export declare function useOnPlaybackStateChange(): PlaybackStateResult;
