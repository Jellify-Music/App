import type { DownloadedTrack, DownloadedPlaylist } from '../types/DownloadTypes';
export interface UseDownloadedTracksResult {
    /** All downloaded tracks */
    downloadedTracks: DownloadedTrack[];
    /** All downloaded playlists */
    downloadedPlaylists: DownloadedPlaylist[];
    /** Check if a track is downloaded */
    isTrackDownloaded: (trackId: string) => boolean;
    /** Check if a playlist is fully downloaded */
    isPlaylistDownloaded: (playlistId: string) => boolean;
    /** Check if a playlist is partially downloaded */
    isPlaylistPartiallyDownloaded: (playlistId: string) => boolean;
    /** Get downloaded track info */
    getDownloadedTrack: (trackId: string) => DownloadedTrack | undefined;
    /** Get downloaded playlist info */
    getDownloadedPlaylist: (playlistId: string) => DownloadedPlaylist | undefined;
    /** Refresh downloaded content list */
    refresh: () => void;
    /** Loading state */
    isLoading: boolean;
}
/**
 * Hook for accessing downloaded tracks and playlists
 */
export declare function useDownloadedTracks(): UseDownloadedTracksResult;
