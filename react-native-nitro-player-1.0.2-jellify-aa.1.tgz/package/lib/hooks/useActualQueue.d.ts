import type { TrackItem } from '../types/PlayerQueue';
export interface UseActualQueueResult {
    /** The current queue in playback order */
    queue: TrackItem[];
    /** Manually refresh the queue */
    refreshQueue: () => void;
    /** Whether the queue is currently loading */
    isLoading: boolean;
}
/**
 * Hook to get the actual playback queue including temporary tracks
 *
 * Returns the complete queue in playback order:
 * [tracks_before_current] + [current] + [playNext_stack] + [upNext_queue] + [remaining_tracks]
 *
 * Auto-updates when:
 * - Track changes
 * - Playback state changes
 *
 * Call `refreshQueue()` after adding tracks via `playNext()` or `addToUpNext()`
 * to immediately see the updated queue.
 *
 * @returns Object containing queue array, refresh function, and loading state
 *
 * @example
 * ```tsx
 * function QueueView() {
 *   const { queue, refreshQueue, isLoading } = useActualQueue();
 *
 *   const handleAddToUpNext = (trackId: string) => {
 *     TrackPlayer.addToUpNext(trackId);
 *     // Refresh queue after adding track
 *     setTimeout(refreshQueue, 100);
 *   };
 *
 *   return (
 *     <ScrollView>
 *       {queue.map((track, index) => (
 *         <Text key={track.id}>
 *           {index + 1}. {track.title}
 *         </Text>
 *       ))}
 *     </ScrollView>
 *   );
 * }
 * ```
 */
export declare function useActualQueue(): UseActualQueueResult;
