import type { TrackItem, Reason } from '../types/PlayerQueue';
export interface TrackChangeResult {
    track: TrackItem | null;
    reason: Reason | undefined;
    isReady: boolean;
}
/**
 * Hook to subscribe to track changes.
 *
 * This hook provides real-time track change updates using native callbacks.
 * Multiple components can use this hook simultaneously without interfering
 * with each other.
 *
 * @returns Object with:
 *   - track: Current track or null if no track is playing
 *   - reason: Reason for the last track change
 *   - isReady: Whether the initial state has been loaded
 *
 * @example
 * ```tsx
 * function NowPlaying() {
 *   const { track, reason, isReady } = useOnChangeTrack()
 *
 *   if (!isReady) return <Text>Loading...</Text>
 *   if (!track) return <Text>No track playing</Text>
 *
 *   return (
 *     <View>
 *       <Text>{track.title}</Text>
 *       <Text>{track.artist}</Text>
 *     </View>
 *   )
 * }
 * ```
 */
export declare function useOnChangeTrack(): TrackChangeResult;
