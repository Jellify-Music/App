import type { DownloadProgress } from '../types/DownloadTypes';
export interface UseDownloadProgressOptions {
    /** Track specific track ID(s) */
    trackIds?: string[];
    /** Track specific download ID(s) */
    downloadIds?: string[];
    /** Only track active downloads */
    activeOnly?: boolean;
}
export interface UseDownloadProgressResult {
    /** Map of trackId to DownloadProgress */
    progressMap: Map<string, DownloadProgress>;
    /** Array of all tracked progress */
    progressList: DownloadProgress[];
    /** Overall progress for tracked downloads (0-1) */
    overallProgress: number;
    /** Whether any download is in progress */
    isDownloading: boolean;
    /** Get progress for a specific track */
    getProgress: (trackId: string) => DownloadProgress | undefined;
}
/**
 * Hook for tracking download progress
 */
export declare function useDownloadProgress(options?: UseDownloadProgressOptions): UseDownloadProgressResult;
