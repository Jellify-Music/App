import type { EqualizerPreset } from '../types/EqualizerTypes';
export interface UseEqualizerPresetsResult {
    /** All available presets */
    presets: EqualizerPreset[];
    /** Built-in presets only */
    builtInPresets: EqualizerPreset[];
    /** Custom user presets */
    customPresets: EqualizerPreset[];
    /** Apply a preset by name */
    applyPreset: (name: string) => Promise<boolean>;
    /** Save current settings as custom preset */
    saveCustomPreset: (name: string) => Promise<boolean>;
    /** Delete a custom preset */
    deleteCustomPreset: (name: string) => Promise<boolean>;
    /** Currently applied preset name */
    currentPreset: string | null;
    /** Whether presets are loading */
    isLoading: boolean;
    /** Refresh presets from native */
    refreshPresets: () => void;
}
export declare function useEqualizerPresets(): UseEqualizerPresetsResult;
