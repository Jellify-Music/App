/**
 * Hook to get the last seek event information
 * @returns Object with last seek position and total duration, or undefined if no seek has occurred
 */
export declare function useOnSeek(): {
    position: number | undefined;
    totalDuration: number | undefined;
};
