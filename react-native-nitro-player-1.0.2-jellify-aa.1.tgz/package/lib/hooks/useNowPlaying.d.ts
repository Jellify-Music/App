import type { PlayerState } from '../types/PlayerQueue';
/**
 * Hook to get the current player state (same as TrackPlayer.getState())
 *
 * This hook provides all player state information including:
 * - Current track
 * - Current position and duration
 * - Playback state (playing, paused, stopped)
 * - Current playlist ID
 * - Current track index
 *
 * The hook uses native callbacks for immediate updates when state changes.
 * Multiple components can use this hook simultaneously.
 *
 * @returns PlayerState object with all current player information
 *
 * @example
 * ```tsx
 * function PlayerComponent() {
 *   const state = useNowPlaying()
 *
 *   return (
 *     <View>
 *       {state.currentTrack && (
 *         <Text>Now Playing: {state.currentTrack.title}</Text>
 *       )}
 *       <Text>Position: {state.currentPosition} / {state.totalDuration}</Text>
 *       <Text>State: {state.currentState}</Text>
 *       <Text>Playlist: {state.currentPlaylistId || 'None'}</Text>
 *       <Text>Index: {state.currentIndex}</Text>
 *     </View>
 *   )
 * }
 * ```
 */
export declare function useNowPlaying(): PlayerState;
