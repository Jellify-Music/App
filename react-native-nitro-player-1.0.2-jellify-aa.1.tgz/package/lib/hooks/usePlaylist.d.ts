import type { Playlist, TrackItem } from '../types/PlayerQueue';
export interface UsePlaylistResult {
    /** The currently loaded playlist */
    currentPlaylist: Playlist | null;
    /** ID of the currently loaded playlist */
    currentPlaylistId: string | null;
    /** All available playlists */
    allPlaylists: Playlist[];
    /** All tracks from all playlists (flattened) */
    allTracks: TrackItem[];
    /** Whether the playlists are currently loading */
    isLoading: boolean;
    /** Manually refresh playlist data */
    refreshPlaylists: () => void;
}
/**
 * Hook to manage playlist state
 *
 * Provides current playlist, all playlists, and all tracks across playlists.
 * Automatically refreshes when:
 * - Component mounts
 * - Track changes (to update currentPlaylistId)
 * - Playlists are modified via PlayerQueue methods
 *
 * Call `refreshPlaylists()` after creating/deleting playlists to update the state.
 *
 * @returns Object containing playlist state and refresh function
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { currentPlaylist, allTracks, refreshPlaylists } = usePlaylist();
 *
 *   const handleCreatePlaylist = () => {
 *     PlayerQueue.createPlaylist('New Playlist');
 *     refreshPlaylists(); // Refresh to see the new playlist
 *   };
 *
 *   return (
 *     <View>
 *       <Text>{currentPlaylist?.name}</Text>
 *       <Text>Total tracks: {allTracks.length}</Text>
 *     </View>
 *   );
 * }
 * ```
 */
export declare function usePlaylist(): UsePlaylistResult;
