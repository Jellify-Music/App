import type { DownloadStorageInfo } from '../types/DownloadTypes';
export interface UseDownloadStorageResult {
    /** Storage information */
    storageInfo: DownloadStorageInfo | null;
    /** Loading state */
    isLoading: boolean;
    /** Refresh storage info */
    refresh: () => Promise<void>;
    /** Formatted total downloaded size (e.g., "2.5 GB") */
    formattedSize: string;
    /** Formatted available space (e.g., "10.2 GB") */
    formattedAvailable: string;
    /** Usage percentage (0-100) */
    usagePercentage: number;
}
/**
 * Hook for accessing download storage information
 */
export declare function useDownloadStorage(): UseDownloadStorageResult;
