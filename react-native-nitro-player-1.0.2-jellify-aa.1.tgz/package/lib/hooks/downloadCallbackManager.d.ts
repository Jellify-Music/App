import type { DownloadProgress, DownloadState, DownloadedTrack, DownloadError } from '../types/DownloadTypes';
type ProgressCallback = (progress: DownloadProgress) => void;
type StateChangeCallback = (downloadId: string, trackId: string, state: DownloadState, error?: DownloadError) => void;
type CompleteCallback = (downloadedTrack: DownloadedTrack) => void;
/**
 * Internal subscription manager for download callbacks.
 * Allows multiple hooks to subscribe to a single native callback.
 */
declare class DownloadCallbackSubscriptionManager {
    private progressSubscribers;
    private stateChangeSubscribers;
    private completeSubscribers;
    private isProgressRegistered;
    private isStateChangeRegistered;
    private isCompleteRegistered;
    /**
     * Subscribe to download progress updates
     * @returns Unsubscribe function
     */
    subscribeToProgress(callback: ProgressCallback): () => void;
    /**
     * Subscribe to download state changes
     * @returns Unsubscribe function
     */
    subscribeToStateChange(callback: StateChangeCallback): () => void;
    /**
     * Subscribe to download completions
     * @returns Unsubscribe function
     */
    subscribeToComplete(callback: CompleteCallback): () => void;
    private ensureProgressRegistered;
    private ensureStateChangeRegistered;
    private ensureCompleteRegistered;
}
export declare const downloadCallbackManager: DownloadCallbackSubscriptionManager;
export {};
