import type { TAudioDevice } from '../specs/AudioDevices.nitro';
/**
 * Hook to get audio devices (Android only)
 *
 * Polls for device changes every 2 seconds
 *
 * @returns Object containing the current list of audio devices
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { devices } = useAudioDevices()
 *
 *   return (
 *     <View>
 *       {devices.map(device => (
 *         <Text key={device.id}>{device.name}</Text>
 *       ))}
 *     </View>
 *   )
 * }
 * ```
 */
export declare function useAudioDevices(): {
    devices: TAudioDevice[];
};
