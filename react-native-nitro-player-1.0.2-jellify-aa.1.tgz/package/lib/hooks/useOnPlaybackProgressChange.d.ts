/**
 * Hook to get the current playback progress
 * @returns Object with current position, total duration, and manual seek indicator
 */
export declare function useOnPlaybackProgressChange(): {
    position: number;
    totalDuration: number;
    isManuallySeeked: boolean | undefined;
};
