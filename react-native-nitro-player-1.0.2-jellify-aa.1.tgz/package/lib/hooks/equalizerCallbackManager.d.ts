import type { EqualizerBand } from '../types/EqualizerTypes';
type EnabledChangeCallback = (enabled: boolean) => void;
type BandChangeCallback = (bands: EqualizerBand[]) => void;
type PresetChangeCallback = (presetName: string | null) => void;
/**
 * Internal subscription manager that allows multiple hooks to subscribe
 * to equalizer callbacks. This solves the problem where registering
 * a new callback overwrites the previous one.
 */
declare class EqualizerCallbackSubscriptionManager {
    private enabledChangeSubscribers;
    private bandChangeSubscribers;
    private presetChangeSubscribers;
    private isEnabledChangeRegistered;
    private isBandChangeRegistered;
    private isPresetChangeRegistered;
    /**
     * Subscribe to enabled state changes
     * @returns Unsubscribe function
     */
    subscribeToEnabledChange(callback: EnabledChangeCallback): () => void;
    /**
     * Subscribe to band changes
     * @returns Unsubscribe function
     */
    subscribeToBandChange(callback: BandChangeCallback): () => void;
    /**
     * Subscribe to preset changes
     * @returns Unsubscribe function
     */
    subscribeToPresetChange(callback: PresetChangeCallback): () => void;
    private ensureEnabledChangeRegistered;
    private ensureBandChangeRegistered;
    private ensurePresetChangeRegistered;
}
export declare const equalizerCallbackManager: EqualizerCallbackSubscriptionManager;
export {};
